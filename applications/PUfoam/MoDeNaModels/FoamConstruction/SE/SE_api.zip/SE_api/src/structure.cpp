#include "structure.hpp"
using namespace std;

Vertex::Vertex(double x,double y,double z) {
	X=x;
	Y=y;
	Z=z;
	}

Edge::Edge(int v0,int v1,char wrap) {
	V0=v0;
	V1=v1;
	Wrap=wrap;	
	}
	
Surface::Surface(vector<string> data) {
	for (int i=2;i<data.size();i++) {
		edgeList.push_back(stoi(data[i]));
		}
	}
	
Volume::Volume(vector<string> data) {
	for (int i=2;i<data.size();i++) {
		surfaceList.push_back(stoi(data[i]));
		}
	}
