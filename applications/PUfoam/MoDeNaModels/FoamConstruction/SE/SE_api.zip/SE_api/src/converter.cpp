#include "converter.hpp"

using namespace std;

Converter::Converter() {}
	
bool Converter::LoadGeo(ifstream &fin) {
	string line;
	string val;
	vector<string> sl;
	minx=0;
	miny=minx;
	minz=minx;
	maxx=1;
	maxy=maxx;
	maxz=maxz;
	
	Edge *e;
	Surface *surf;
	Volume *vol;
	int i=0;
	//Structure counters
	int vertNum=0;
	int edgeNum=0;
	int surfNum=0;
	int volNum=0;
	int cacheMem=50;
	//Structure alloc
	bool reservedV=false;
	bool reservedE=false;
	bool reservedSurf=false;
	bool reservedVol=false;
	
	float num;
	if (fin.is_open())
	{
		cout<< "Loading input file..." << endl;
		//loading structure
		while ( getline (fin,line) )
        {
			//allocation
				if (vertNum%cacheMem==0 && !reservedV) {
					vertexList.reserve(vertNum+cacheMem);
					reservedV=true;
				}
				if (edgeNum%cacheMem==0 && !reservedE) {
					edgeList.reserve(edgeNum+cacheMem);
					reservedE=true;
				}
				if (surfNum%cacheMem==0 && !reservedSurf) {
					surfaceList.reserve(surfNum+cacheMem);
					reservedSurf=true;
				}
				if (volNum%cacheMem==0 && !reservedVol) {
					volumeList.reserve(volNum+cacheMem);
					reservedVol=true;
				}
				
			//parsing line
				sl=ParseLnGeo(line);			
				if (sl[0]=="Point") {
					vertNum++;
					reservedV=false;
					//shared_ptr<Vertex> v(new Vertex(stof(sl[2]),stof(sl[3]),stof(sl[4])));
					vertexList.push_back(Vertex(stod(sl[2])-1,stod(sl[3])-1,stod(sl[4])-1));
					}
				else if (sl[0]=="Line") {
					edgeNum++;
					reservedE=false;
					int v0=stoi(sl[2]);
					int v1=stoi(sl[3]);
					char wrapping=computeWrapping(v0,v1);
					edgeList.push_back(Edge(v0,v1,wrapping));
					}	
				else if (sl[0]=="Line Loop") {
						surfNum++;
						surfaceList.push_back(Surface(sl));
					}
				else if (sl[0]=="Surface Loop") {
						volNum++;
						volumeList.push_back(Volume(sl));
					}
			}
	} else {
		cout<< "Can not open input file." << endl;
		return false;
		}
		
	return true;
};
vector<string> Converter::ParseLnGeo(string line) {
		bool id=false;
		bool order=false;
		bool value=false;
		int i=0;
		int previ=0;
		string val;
		vector<string> strVec;
		
		while(line[previ]==' ') previ++;
		for (i=previ;i<line.size();i++) {
			if (!id && line[i]=='(') {				
				val=line.substr(previ,i-previ-1);
				if (val=="Volume") {		
					while(line[i]!=';') i++;
					i++;
					if (i>=line.size()) {
						strVec.push_back(val);
						break;
						}
					while(line[i]==' ') i++;
					i--;
				} else {
					id=true;
					strVec.push_back(val);
					}				
				previ=i+1;
				}
			else if (!order && id && line[i]==')') {
					order=true;
					strVec.push_back(line.substr(previ,i-previ));
				}
			else if (order && id && line[i]=='{') {
				previ=i+1;
				}
			else if (line[i]==';') {
				stringstream valStream(line.substr(previ,i-previ-1));
				while (getline(valStream,val,',')) {
					strVec.push_back(val);			
					}				
				}
			}
		return strVec;
	};
	
	
	
char Converter::computeWrapping(int v0,int v1) {
                        //set wrapping 2bits for each coordinate
                        //x y z : 00 00 00
                        //first bit plus = 10
                        //second bit minus = 01
                        //both bits 00 or 11 = no wraping
                        //cout << vx0 <<" " << vy0 << " " << vz0 << endl;
                       // cout << vx1 <<" " << vy1 << " " << vz1 << endl;
                        //cout << "--------" << endl;

                        char curr_e_wrapping=0;
                        
                
                        return curr_e_wrapping;
}


char Converter::getInvWrapping(char curr_e_wrapping) {
    return (((curr_e_wrapping&48)==0)? 0 : ((curr_e_wrapping&48)^48))^(((curr_e_wrapping&12)==0)? 0 : ((curr_e_wrapping&12)^12))^(((curr_e_wrapping&3)==0)? 0 : ((curr_e_wrapping&3)^3));
}
bool Converter::SaveFe(ofstream &se_file) {
			int i;
			int j;
			
			/*
		 * Generates input file for SurfaceEvolver
		 * Use voro++
		 */

		if (se_file.is_open()) {
		cout << "Generating output for Surface Evolver..." << endl;
		
		se_file << endl << "vertices" << endl;
		for (i=0;i<vertexList.size();i++) {
			se_file << i+1 << " " << vertexList[i].X << " " << vertexList[i].Y << " " << vertexList[i].Z << endl;
		}
		
		se_file << endl << "edges" << endl;
		for (i=0;i<edgeList.size();i++) {
			se_file << i+1 << " " << edgeList[i].V0 << " " << edgeList[i].V1 << endl;
			}
		
		se_file << endl <<"faces" << endl;
		for (i=0;i<surfaceList.size();i++) {
			se_file << i+1 << " ";
			for (j=0;j<surfaceList[i].edgeList.size();j++) {
				se_file << surfaceList[i].edgeList[j] << " ";
			}
			se_file << endl;              
		}
		se_file << endl << "bodies" << endl;

		for (i=0;i<volumeList.size();i++) {
			se_file << i+1 << " ";
			for (j=0;j<volumeList[i].surfaceList.size();j++) {
				se_file << volumeList[i].surfaceList[j] << " ";
			}
			se_file << endl;              
		}

		cout << "...Finished" << endl;
	} else {
		cout<< "Can not open output file." << endl;
		return false;		
	}
	
	return true;
	}
