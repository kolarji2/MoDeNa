#ifndef structure_hpp
#define structure_hpp
#include <vector>
#include <iostream>
#include <string>
using namespace std;

class Vertex {
public:
    double X;
    double Y;
    double Z;
    Vertex (double x, double y,double z);
};

class Edge {
public:
    int V0;
    int V1;
    char Wrap;
    Edge(int v0,int v1,char wrap);
};
class Surface {
public:
	vector<int> edgeList;
    Surface(vector<string> data);
};

class Volume{
public:
	vector<int> surfaceList;
    Volume(vector<string> data);
};
#endif
