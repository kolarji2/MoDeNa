astyle --style=linux -xl -xk -pdtLnU -M80 *.cpp *.hpp
