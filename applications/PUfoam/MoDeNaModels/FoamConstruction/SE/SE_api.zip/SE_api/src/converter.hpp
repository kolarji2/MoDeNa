#ifndef converter_hpp
#define converter_hpp
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <memory>
#include "structure.hpp"

using namespace std;

class Converter {
private:
	
	 vector<Vertex> vertexList;
	 vector<Edge> edgeList;
	 vector<Surface> surfaceList;
	 vector<Volume> volumeList;
	 //box size
	 double minx,maxx,miny,maxy,minz,maxz;
public:
    Converter();

    bool LoadGeo(ifstream &fin);
    vector<string> ParseLnGeo(string line);
    char computeWrapping(int v0,int v1);
    char getInvWrapping(char curr_e_wrapping);
    bool SaveFe(ofstream &fout);
};


#endif
