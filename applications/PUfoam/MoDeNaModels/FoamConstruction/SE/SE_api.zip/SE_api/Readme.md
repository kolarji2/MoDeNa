
##build cmd
cd src
make

##run cmd:
main inputfilePath outpufilePath
Example:
main PeriodicRVE.geo PeriodicRVE.fe

#can be viewed by
evolver PeriodicRVE.fe
and inner cmd #s
