#!/bin/sh
cmake .
make
#./SE_api -g random -n 9 -p foam.gnu
#
./SE_api -i PeriodicRVE.geo -o PeriodicRVE.fe
#evolver -f PeriodicRVE.cmd PeriodicRVE.fe
